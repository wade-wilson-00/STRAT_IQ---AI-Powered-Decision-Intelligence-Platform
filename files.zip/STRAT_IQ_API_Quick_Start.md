# ⚡ STRAT_IQ API Development - Quick Start (2-3 Hours)

**Goal:** Build FastAPI backend that serves your trained ML models

---

## 🎯 WHAT YOU'LL BUILD

```
Your trained models:
├─ churn_classifier.pkl (Random Forest, saved)
├─ revenue_forecaster.pkl (Regression, saved)
└─ scalers (StandardScaler, saved)

Your API will provide:
├─ POST /predict/churn → Get churn risk for customer
├─ POST /predict/revenue → Forecast SaaS revenue
├─ GET /health → Check if API is running
└─ Interactive docs at /docs
```

---

## 📋 QUICK CHECKLIST

```
Phase 4: API Backend (This Week)
├─ [ ] Create project structure
├─ [ ] Setup FastAPI & dependencies
├─ [ ] Create model loading layer
├─ [ ] Define request/response schemas
├─ [ ] Implement business logic (services)
├─ [ ] Create API routes/endpoints
├─ [ ] Test endpoints locally
├─ [ ] Add error handling & logging
└─ [ ] Document API (auto-generated at /docs)

Total time: 2-3 hours
Difficulty: Straightforward (mostly copying code)
```

---

## 🚀 START HERE (5 MINUTES)

### **Step 1: Create Project Directory**
```bash
mkdir strat-iq-backend
cd strat-iq-backend

# Copy your saved models here
mkdir models
# Put your .pkl files here:
# - churn_classifier.pkl
# - revenue_forecaster.pkl
# - scaler_churn.pkl
# - scaler_revenue.pkl
```

### **Step 2: Create Virtual Environment**
```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
```

### **Step 3: Install Dependencies**
```bash
pip install fastapi uvicorn pydantic python-dotenv numpy pandas scikit-learn joblib
```

### **Step 4: Create requirements.txt**
```bash
pip freeze > requirements.txt
```

---

## 🏗️ PROJECT STRUCTURE (Copy This)

Create this exact folder structure:
```
strat-iq-backend/
├── app/
│   ├── __init__.py                 (empty file)
│   ├── main.py                     (FastAPI app)
│   ├── config.py                   (settings)
│   ├── models/
│   │   ├── __init__.py             (empty)
│   │   └── loader.py               (load ML models)
│   ├── schemas/
│   │   ├── __init__.py             (empty)
│   │   ├── churn.py                (churn schemas)
│   │   └── revenue.py              (revenue schemas)
│   ├── routes/
│   │   ├── __init__.py             (empty)
│   │   ├── health.py               (health check)
│   │   ├── churn.py                (churn endpoints)
│   │   └── revenue.py              (revenue endpoints)
│   └── services/
│       ├── __init__.py             (empty)
│       ├── churn_service.py        (churn logic)
│       └── revenue_service.py      (revenue logic)
│
├── models/                          (your .pkl files)
│   ├── churn_classifier.pkl
│   ├── revenue_forecaster.pkl
│   ├── scaler_churn.pkl
│   └── scaler_revenue.pkl
│
├── .env                             (config file)
├── .env.example                     (template)
└── requirements.txt
```

---

## 📝 CODE FILES (Copy-Paste Ready)

**The full implementation guide has all code ready to copy.**

Key files in order of creation:

### **1. app/config.py** (Settings)
```python
from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    api_title: str = "STRAT_IQ Intelligence Layer"
    api_version: str = "1.0.0"
    debug: bool = True
    
    churn_model_path: str = "models/churn_classifier.pkl"
    revenue_model_path: str = "models/revenue_forecaster.pkl"
    churn_scaler_path: str = "models/scaler_churn.pkl"
    revenue_scaler_path: str = "models/scaler_revenue.pkl"
    
    log_level: str = "INFO"
    cors_origins: List[str] = ["http://localhost:3000", "http://localhost:5173"]
    
    class Config:
        env_file = ".env"

settings = Settings()
```

### **2. app/models/loader.py** (Load Models)
- Loads your saved .pkl files
- Caches them in memory
- Provides getters for routes

### **3. app/schemas/churn.py** (Input/Output Format)
- Defines what churn prediction input looks like
- Validates ranges (0-1 for engagement_score, etc.)
- Auto-generates API docs

### **4. app/schemas/revenue.py** (Revenue Input/Output)
- Defines revenue forecast structure
- Validates MRR, growth rates, etc.

### **5. app/services/churn_service.py** (Churn Logic)
- Takes validated input
- Scales features with saved scaler
- Runs through trained model
- Identifies top risk drivers
- Returns formatted output

### **6. app/services/revenue_service.py** (Revenue Logic)
- Prepares features
- Makes prediction
- Generates month-by-month forecast
- Calculates confidence level

### **7. app/routes/health.py** (Health Endpoints)
```python
@router.get("")
async def health_check():
    return {"status": "✅ healthy", "models_loaded": True}
```

### **8. app/routes/churn.py** (Churn Endpoints)
```python
@router.post("", response_model=ChurnPredictionOutput)
async def predict_churn(input_data: ChurnPredictionInput):
    return ChurnPredictionService.predict(input_data)
```

### **9. app/routes/revenue.py** (Revenue Endpoints)
```python
@router.post("", response_model=RevenueForecastOutput)
async def forecast_revenue(input_data: RevenueForecastInput):
    return RevenueForecastService.forecast(input_data)
```

### **10. app/main.py** (FastAPI Application)**
- Creates FastAPI app
- Includes all routers
- Configures CORS
- Loads models on startup

---

## ▶️ RUN YOUR API (5 MINUTES)

### **Start the server:**
```bash
python -m uvicorn app.main:app --reload --port 8000
```

### **You should see:**
```
✅ INFO:     Uvicorn running on http://127.0.0.1:8000
✅ Models loaded successfully
```

### **Visit:**
- **Interactive Docs:** http://localhost:8000/docs
- **Health Check:** http://localhost:8000/health
- **API Root:** http://localhost:8000/

---

## 🧪 TEST YOUR ENDPOINTS

### **In the browser:**
1. Go to http://localhost:8000/docs
2. Expand "POST /predict/churn"
3. Click "Try it out"
4. Fill in sample data:
   ```json
   {
     "engagement_score": 0.65,
     "nps_score": 7,
     "product_adoption_rate": 0.75,
     "payment_failures": 2,
     "support_tickets_last_30d": 3,
     "customer_age_months": 18,
     "cac_payback_months": 8,
     "active_users_ratio": 0.6,
     "contract_length_months": 12,
     "churn_risk_flag": 0
   }
   ```
5. Click "Execute"
6. See response:
   ```json
   {
     "churn_probability": 0.42,
     "churn_percentage": 42.0,
     "risk_level": "MEDIUM",
     "top_drivers": [...],
     "recommendation": "Monitor closely..."
   }
   ```

---

## 💡 KEY CONCEPTS

### **Pydantic Schemas**
```
Define what data your API accepts and returns
├─ Automatic validation (ranges, types)
├─ Auto-generated documentation
└─ Nice error messages if invalid
```

### **Services**
```
Business logic layer
├─ Takes validated input
├─ Loads models
├─ Makes predictions
└─ Formats output
```

### **Routes**
```
HTTP endpoints
├─ POST /predict/churn
├─ POST /predict/revenue
└─ GET /health
```

### **Model Loading**
```
Load .pkl files once at startup
├─ Cache in memory
├─ Reuse for all requests
└─ Fast predictions
```

---

## 🔧 TROUBLESHOOTING

### **Error: "No module named 'app'"**
```
Solution: Run from project root where app/ folder is
```

### **Error: "Model file not found"**
```
Solution: Make sure .pkl files are in models/ folder
Check: churn_classifier.pkl, revenue_forecaster.pkl, scaler_churn.pkl, scaler_revenue.pkl
```

### **Error: "CORS issue"**
```
Solution: Frontend might be on different port
Update .env: CORS_ORIGINS=["http://localhost:5173"]
```

### **Models not loading**
```
Solution: Check model paths in .env
Verify: python -c "import joblib; joblib.load('models/churn_classifier.pkl')"
```

---

## 🎯 EXPECTED RESULTS

When you POST to `/predict/churn`:
```json
{
  "churn_probability": 0.42,
  "churn_percentage": 42.0,
  "risk_level": "MEDIUM",
  "top_drivers": [
    {"factor": "payment_failures", "impact": "HIGH", "value": 2.0},
    {"factor": "engagement_score", "impact": "MEDIUM", "value": 0.65}
  ],
  "recommendation": "📋 Monitor customer activity closely...",
  "model_version": "1.0.0"
}
```

When you POST to `/predict/revenue`:
```json
{
  "predicted_mrr": 63000.0,
  "arr_projected": 756000.0,
  "confidence_level": "MEDIUM",
  "forecast_months": [
    {"month": 1, "month_label": "M+1", "projected_mrr": 51500.0, "growth_percentage": 3.0},
    ...
  ],
  "key_metrics": {...}
}
```

---

## 📚 FULL DETAILS

For complete implementation with all code, see:
`STRAT_IQ_FastAPI_Complete_Endpoint_Guide.md`

That file has:
- ✅ Every single line of code
- ✅ All 10 steps explained
- ✅ Error handling examples
- ✅ Testing instructions
- ✅ Deployment options

---

## 🚀 NEXT PHASE (After API Works)

Once API is running:

**Phase 5: Frontend Integration**
1. Your Next.js frontend calls `http://localhost:8000/predict/churn`
2. React Hook Form + TanStack Query handle requests
3. Display results beautifully with Recharts

**Example Hook:**
```typescript
function useChurnPrediction() {
  return useMutation({
    mutationFn: async (data: ChurnInput) =>
      fetch('http://localhost:8000/predict/churn', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {'Content-Type': 'application/json'}
      }).then(r => r.json())
  })
}
```

---

## ✅ SUCCESS CRITERIA

When complete, you have:
- ✅ FastAPI server running on port 8000
- ✅ Both models serving predictions
- ✅ Interactive API docs at /docs
- ✅ Health check endpoint working
- ✅ Request validation with helpful errors
- ✅ Structured responses with predictions
- ✅ Ready for frontend integration
- ✅ Production-ready code

---

## ⏱️ TIME BREAKDOWN

```
Setup & structure:        20 min
Config & model loading:   20 min
Schemas (input/output):   20 min
Services (logic):         40 min
Routes (endpoints):       20 min
Testing:                  20 min

TOTAL: 2-3 hours
```

---

**YOU GOT THIS! 🚀**

Start with the complete guide and follow step-by-step. By tonight, you'll have a production-ready API serving your ML models!

Let me know when you're done and we'll move to Phase 5 (Frontend Integration)! 💪
