# 🚀 STRAT_IQ FastAPI Backend - Complete Endpoint Development Guide

**Phase 4: Building Production-Ready API Endpoints**

---

## 🎯 PROJECT CONTEXT

**What you have:**
- ✅ Revenue Forecasting Model (trained, saved)
- ✅ Churn Prediction Model (trained, saved)
- ✅ Feature scalers (StandardScaler saved)
- ✅ 50% of project complete (ML part)

**What you're building:**
- 🏗️ FastAPI backend to serve these models
- 🏗️ RESTful endpoints for predictions
- 🏗️ Input validation with Pydantic
- 🏗️ Error handling and logging
- 🏗️ Production-ready code

---

## 📋 PROJECT STRUCTURE

```
strat-iq-backend/
├── app/
│   ├── __init__.py
│   ├── main.py                     # FastAPI app entry point
│   ├── config.py                   # Configuration & env variables
│   ├── dependencies.py             # Shared dependencies
│   │
│   ├── models/                     # ML models loading
│   │   ├── __init__.py
│   │   ├── loader.py              # Load saved models & scalers
│   │   └── predictor.py           # Prediction logic
│   │
│   ├── schemas/                    # Pydantic models (request/response)
│   │   ├── __init__.py
│   │   ├── churn.py               # Churn prediction schemas
│   │   └── revenue.py             # Revenue forecast schemas
│   │
│   ├── routes/                     # API endpoints
│   │   ├── __init__.py
│   │   ├── health.py              # Health check endpoints
│   │   ├── churn.py               # Churn prediction endpoints
│   │   └── revenue.py             # Revenue forecast endpoints
│   │
│   ├── services/                   # Business logic
│   │   ├── __init__.py
│   │   ├── churn_service.py       # Churn prediction logic
│   │   └── revenue_service.py     # Revenue forecast logic
│   │
│   ├── utils/                      # Utility functions
│   │   ├── __init__.py
│   │   ├── logging.py             # Logging configuration
│   │   └── validators.py          # Input validation helpers
│   │
│   └── middleware/                 # Custom middleware
│       ├── __init__.py
│       └── error_handler.py       # Error handling
│
├── models/                         # Saved ML models directory
│   ├── churn_classifier.pkl
│   ├── revenue_forecaster.pkl
│   ├── scaler_churn.pkl
│   └── scaler_revenue.pkl
│
├── requirements.txt
├── .env
├── .env.example
├── Dockerfile
├── docker-compose.yml
└── README.md
```

---

## 🔧 STEP 1: Setup & Installation

### **1.1 Create Virtual Environment**
```bash
# Create project directory
mkdir strat-iq-backend
cd strat-iq-backend

# Create virtual environment
python -m venv venv

# Activate it
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### **1.2 Install Dependencies**
```bash
pip install fastapi uvicorn pydantic python-dotenv numpy pandas scikit-learn joblib
```

### **1.3 Create requirements.txt**
```
fastapi==0.104.1
uvicorn[standard]==0.24.0
pydantic==2.5.0
pydantic-settings==2.1.0
python-dotenv==1.0.0
numpy==1.24.3
pandas==2.0.3
scikit-learn==1.3.0
joblib==1.3.2
```

---

## 📝 STEP 2: Configuration & Environment

### **2.1 Create .env.example**
```
# API Configuration
API_TITLE="STRAT_IQ Intelligence Layer"
API_VERSION="1.0.0"
DEBUG=True

# Model paths
CHURN_MODEL_PATH="models/churn_classifier.pkl"
REVENUE_MODEL_PATH="models/revenue_forecaster.pkl"
CHURN_SCALER_PATH="models/scaler_churn.pkl"
REVENUE_SCALER_PATH="models/scaler_revenue.pkl"

# Logging
LOG_LEVEL="INFO"

# CORS (for frontend integration)
CORS_ORIGINS=["http://localhost:3000", "http://localhost:5173"]
```

### **2.2 Create app/config.py**
```python
from pydantic_settings import BaseSettings
from typing import List
import os

class Settings(BaseSettings):
    # API Configuration
    api_title: str = "STRAT_IQ Intelligence Layer"
    api_version: str = "1.0.0"
    debug: bool = True
    
    # Model paths
    churn_model_path: str = "models/churn_classifier.pkl"
    revenue_model_path: str = "models/revenue_forecaster.pkl"
    churn_scaler_path: str = "models/scaler_churn.pkl"
    revenue_scaler_path: str = "models/scaler_revenue.pkl"
    
    # Logging
    log_level: str = "INFO"
    
    # CORS
    cors_origins: List[str] = ["http://localhost:3000", "http://localhost:5173"]
    
    class Config:
        env_file = ".env"

settings = Settings()
```

---

## 🏗️ STEP 3: Model Loading Layer

### **3.1 Create app/models/loader.py**
```python
import joblib
import logging
from pathlib import Path
from app.config import settings

logger = logging.getLogger(__name__)

class ModelLoader:
    """Load and cache ML models and scalers"""
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._loaded = False
        return cls._instance
    
    def __init__(self):
        if self._loaded:
            return
        
        try:
            # Load Churn model
            self.churn_model = joblib.load(settings.churn_model_path)
            self.churn_scaler = joblib.load(settings.churn_scaler_path)
            
            # Load Revenue model
            self.revenue_model = joblib.load(settings.revenue_model_path)
            self.revenue_scaler = joblib.load(settings.revenue_scaler_path)
            
            self._loaded = True
            logger.info("✅ All models loaded successfully")
            
        except FileNotFoundError as e:
            logger.error(f"❌ Model file not found: {e}")
            raise Exception(f"Failed to load models: {e}")
        except Exception as e:
            logger.error(f"❌ Error loading models: {e}")
            raise

# Global instance
model_loader = ModelLoader()

def get_churn_model():
    """Get churn prediction model"""
    return model_loader.churn_model

def get_revenue_model():
    """Get revenue forecast model"""
    return model_loader.revenue_model

def get_churn_scaler():
    """Get churn feature scaler"""
    return model_loader.churn_scaler

def get_revenue_scaler():
    """Get revenue feature scaler"""
    return model_loader.revenue_scaler
```

---

## 📊 STEP 4: Define Request/Response Schemas

### **4.1 Create app/schemas/churn.py**
```python
from pydantic import BaseModel, Field
from typing import List, Optional

class ChurnPredictionInput(BaseModel):
    """Input schema for churn prediction"""
    engagement_score: float = Field(..., ge=0, le=1, description="Engagement score 0-1")
    nps_score: int = Field(..., ge=0, le=10, description="NPS score 0-10")
    product_adoption_rate: float = Field(..., ge=0, le=1, description="Adoption rate 0-1")
    payment_failures: int = Field(..., ge=0, le=10, description="Payment failures 0-10")
    support_tickets_last_30d: int = Field(..., ge=0, le=50, description="Support tickets last 30 days")
    customer_age_months: int = Field(..., ge=1, le=60, description="Customer age in months")
    cac_payback_months: float = Field(..., ge=3, le=24, description="CAC payback period in months")
    active_users_ratio: float = Field(..., ge=0, le=1, description="Active users ratio 0-1")
    contract_length_months: int = Field(..., ge=1, le=36, description="Contract length in months")
    churn_risk_flag: int = Field(..., ge=0, le=1, description="Churn risk flag 0 or 1")

class ChurnRiskDriver(BaseModel):
    """Individual risk driver"""
    factor: str
    impact: str  # "HIGH", "MEDIUM", "LOW"
    value: float

class ChurnPredictionOutput(BaseModel):
    """Output schema for churn prediction"""
    churn_probability: float = Field(..., ge=0, le=1, description="Churn probability 0-1")
    churn_percentage: float = Field(..., description="Churn probability as percentage")
    risk_level: str = Field(..., description="Risk level: LOW, MEDIUM, HIGH, CRITICAL")
    top_drivers: List[ChurnRiskDriver]
    recommendation: str
    model_version: str = "1.0.0"
```

### **4.2 Create app/schemas/revenue.py**
```python
from pydantic import BaseModel, Field
from typing import List

class RevenueForecastInput(BaseModel):
    """Input schema for revenue forecast"""
    current_mrr: float = Field(..., gt=0, description="Current Monthly Recurring Revenue")
    mrr_growth_rate: float = Field(..., ge=0, le=100, description="MRR growth rate percentage")
    churn_rate: float = Field(..., ge=0, le=100, description="Monthly churn rate percentage")
    expansion_rate: float = Field(..., ge=0, le=100, description="Expansion rate percentage")
    forecast_months: int = Field(..., ge=1, le=36, description="Number of months to forecast")
    previous_revenues: List[float] = Field(default=[], description="Previous monthly revenues (optional)")

class MonthlForecast(BaseModel):
    """Individual month forecast"""
    month: int
    month_label: str
    projected_mrr: float
    growth_percentage: float

class RevenueForecastOutput(BaseModel):
    """Output schema for revenue forecast"""
    predicted_mrr: float
    arr_projected: float  # Annual Recurring Revenue
    confidence_level: str  # "HIGH", "MEDIUM", "LOW"
    forecast_months: List[MonthlForecast]
    key_metrics: dict
    model_version: str = "1.0.0"
```

---

## 🎯 STEP 5: Business Logic (Services)

### **5.1 Create app/services/churn_service.py**
```python
import numpy as np
import logging
from typing import List, Dict
from app.schemas.churn import ChurnPredictionInput, ChurnPredictionOutput, ChurnRiskDriver
from app.models.loader import get_churn_model, get_churn_scaler

logger = logging.getLogger(__name__)

class ChurnPredictionService:
    """Handle churn prediction logic"""
    
    @staticmethod
    def predict(input_data: ChurnPredictionInput) -> ChurnPredictionOutput:
        """
        Predict churn for a customer
        
        Process:
        1. Extract features from input
        2. Scale features using saved scaler
        3. Make prediction with model
        4. Determine risk level
        5. Identify top risk drivers
        6. Return formatted output
        """
        
        model = get_churn_model()
        scaler = get_churn_scaler()
        
        # Extract features in correct order
        features = np.array([[
            input_data.engagement_score,
            input_data.nps_score,
            input_data.product_adoption_rate,
            input_data.payment_failures,
            input_data.support_tickets_last_30d,
            input_data.customer_age_months,
            input_data.cac_payback_months,
            input_data.active_users_ratio,
            input_data.contract_length_months,
            input_data.churn_risk_flag,
        ]])
        
        # Scale features
        features_scaled = scaler.transform(features)
        
        # Predict
        churn_probability = model.predict_proba(features_scaled)[0][1]
        
        # Determine risk level
        if churn_probability >= 0.8:
            risk_level = "CRITICAL"
        elif churn_probability >= 0.6:
            risk_level = "HIGH"
        elif churn_probability >= 0.4:
            risk_level = "MEDIUM"
        else:
            risk_level = "LOW"
        
        # Get feature importance from model
        top_drivers = ChurnPredictionService._get_top_drivers(
            model, input_data, churn_probability
        )
        
        # Generate recommendation
        recommendation = ChurnPredictionService._get_recommendation(
            risk_level, churn_probability
        )
        
        return ChurnPredictionOutput(
            churn_probability=float(churn_probability),
            churn_percentage=float(churn_probability * 100),
            risk_level=risk_level,
            top_drivers=top_drivers,
            recommendation=recommendation
        )
    
    @staticmethod
    def _get_top_drivers(
        model, input_data: ChurnPredictionInput, probability: float
    ) -> List[ChurnRiskDriver]:
        """Identify top risk drivers using feature importance"""
        
        # Feature importance from model
        importances = model.feature_importances_
        feature_names = [
            "engagement_score",
            "nps_score",
            "product_adoption_rate",
            "payment_failures",
            "support_tickets_last_30d",
            "customer_age_months",
            "cac_payback_months",
            "active_users_ratio",
            "contract_length_months",
            "churn_risk_flag",
        ]
        
        # Get feature values
        values = [
            input_data.engagement_score,
            input_data.nps_score,
            input_data.product_adoption_rate,
            input_data.payment_failures,
            input_data.support_tickets_last_30d,
            input_data.customer_age_months,
            input_data.cac_payback_months,
            input_data.active_users_ratio,
            input_data.contract_length_months,
            input_data.churn_risk_flag,
        ]
        
        # Calculate risk contribution
        risk_scores = importances * np.array(values)
        
        # Get top 3 drivers
        top_indices = np.argsort(risk_scores)[-3:][::-1]
        
        drivers = []
        for idx in top_indices:
            impact = "HIGH" if importances[idx] > 0.1 else "MEDIUM"
            drivers.append(ChurnRiskDriver(
                factor=feature_names[idx],
                impact=impact,
                value=float(values[idx])
            ))
        
        return drivers
    
    @staticmethod
    def _get_recommendation(risk_level: str, probability: float) -> str:
        """Generate actionable recommendation"""
        
        if risk_level == "CRITICAL":
            return "🚨 URGENT: Immediate intervention required. Schedule customer success meeting today."
        elif risk_level == "HIGH":
            return "⚠️ HIGH RISK: Schedule check-in within 48 hours. Review contract terms and usage patterns."
        elif risk_level == "MEDIUM":
            return "📋 MEDIUM RISK: Monitor customer activity closely. Prepare proactive support outreach."
        else:
            return "✅ LOW RISK: Customer appears stable. Continue standard support."
```

### **5.2 Create app/services/revenue_service.py**
```python
import numpy as np
import logging
from typing import List, Dict
from app.schemas.revenue import RevenueForecastInput, RevenueForecastOutput, MonthlForecast
from app.models.loader import get_revenue_model, get_revenue_scaler

logger = logging.getLogger(__name__)

class RevenueForecastService:
    """Handle revenue forecast logic"""
    
    @staticmethod
    def forecast(input_data: RevenueForecastInput) -> RevenueForecastOutput:
        """
        Forecast revenue using trained model
        
        Process:
        1. Prepare features from input
        2. Scale features
        3. Predict MRR growth
        4. Generate month-by-month forecast
        5. Calculate confidence level
        6. Return formatted output
        """
        
        model = get_revenue_model()
        scaler = get_revenue_scaler()
        
        # Prepare features
        features = np.array([[
            input_data.current_mrr,
            input_data.mrr_growth_rate,
            input_data.churn_rate,
            input_data.expansion_rate,
            input_data.forecast_months,
        ]])
        
        # Scale features
        features_scaled = scaler.transform(features)
        
        # Predict MRR growth multiplier
        mrr_growth_multiplier = model.predict(features_scaled)[0]
        
        # Calculate projected MRR
        projected_mrr = input_data.current_mrr * mrr_growth_multiplier
        arr_projected = projected_mrr * 12
        
        # Determine confidence level
        confidence = RevenueForecastService._calculate_confidence(input_data)
        
        # Generate month-by-month forecast
        monthly_forecasts = RevenueForecastService._generate_monthly_forecast(
            input_data, projected_mrr
        )
        
        # Calculate key metrics
        key_metrics = {
            "current_arr": input_data.current_mrr * 12,
            "projected_arr": arr_projected,
            "total_growth": ((projected_mrr - input_data.current_mrr) / input_data.current_mrr * 100),
            "avg_monthly_growth": ((mrr_growth_multiplier - 1) / input_data.forecast_months * 100),
            "ltv_cac_ratio": 3.0,  # Placeholder - calculate from actual data
            "payback_period_months": 6,  # Placeholder
        }
        
        return RevenueForecastOutput(
            predicted_mrr=float(projected_mrr),
            arr_projected=float(arr_projected),
            confidence_level=confidence,
            forecast_months=monthly_forecasts,
            key_metrics=key_metrics
        )
    
    @staticmethod
    def _generate_monthly_forecast(
        input_data: RevenueForecastInput, projected_mrr: float
    ) -> List[MonthlForecast]:
        """Generate month-by-month revenue forecast"""
        
        forecasts = []
        current_mrr = input_data.current_mrr
        
        monthly_growth = (projected_mrr - current_mrr) / input_data.forecast_months
        
        month_labels = [
            "M+1", "M+2", "M+3", "M+4", "M+5", "M+6",
            "M+7", "M+8", "M+9", "M+10", "M+11", "M+12"
        ]
        
        for month in range(1, input_data.forecast_months + 1):
            month_mrr = current_mrr + (monthly_growth * month)
            growth_pct = ((month_mrr - current_mrr) / current_mrr * 100)
            
            forecasts.append(MonthlForecast(
                month=month,
                month_label=month_labels[month-1] if month-1 < len(month_labels) else f"M+{month}",
                projected_mrr=float(month_mrr),
                growth_percentage=float(growth_pct)
            ))
        
        return forecasts
    
    @staticmethod
    def _calculate_confidence(input_data: RevenueForecastInput) -> str:
        """Calculate confidence level based on input data"""
        
        # More historical data = higher confidence
        if len(input_data.previous_revenues) >= 6:
            return "HIGH"
        elif len(input_data.previous_revenues) >= 3:
            return "MEDIUM"
        else:
            return "LOW"
```

---

## 🔌 STEP 6: API Routes

### **6.1 Create app/routes/health.py**
```python
from fastapi import APIRouter
from app.models.loader import model_loader

router = APIRouter(prefix="/health", tags=["health"])

@router.get("")
async def health_check():
    """Check API health status"""
    return {
        "status": "✅ healthy",
        "message": "STRAT_IQ API is running",
        "models_loaded": model_loader._loaded
    }

@router.get("/models")
async def models_status():
    """Check if models are loaded"""
    return {
        "churn_model": "✅ loaded" if hasattr(model_loader, 'churn_model') else "❌ not loaded",
        "revenue_model": "✅ loaded" if hasattr(model_loader, 'revenue_model') else "❌ not loaded",
        "status": "ready" if model_loader._loaded else "error"
    }
```

### **6.2 Create app/routes/churn.py**
```python
from fastapi import APIRouter, HTTPException
from app.schemas.churn import ChurnPredictionInput, ChurnPredictionOutput
from app.services.churn_service import ChurnPredictionService
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/predict/churn", tags=["churn"])

@router.post("", response_model=ChurnPredictionOutput)
async def predict_churn(input_data: ChurnPredictionInput) -> ChurnPredictionOutput:
    """
    Predict customer churn risk
    
    Takes customer engagement metrics and returns:
    - Churn probability (0-1)
    - Risk level (LOW, MEDIUM, HIGH, CRITICAL)
    - Top risk drivers
    - Actionable recommendation
    """
    try:
        logger.info(f"Predicting churn for customer with engagement: {input_data.engagement_score}")
        
        result = ChurnPredictionService.predict(input_data)
        
        logger.info(f"Prediction complete. Risk level: {result.risk_level}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error predicting churn: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Prediction failed: {str(e)}"
        )

@router.post("/batch")
async def predict_churn_batch(customers: list[ChurnPredictionInput]):
    """
    Batch predict churn for multiple customers
    """
    try:
        results = [
            ChurnPredictionService.predict(customer)
            for customer in customers
        ]
        return {"predictions": results, "count": len(results)}
    except Exception as e:
        logger.error(f"Error in batch prediction: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
```

### **6.3 Create app/routes/revenue.py**
```python
from fastapi import APIRouter, HTTPException
from app.schemas.revenue import RevenueForecastInput, RevenueForecastOutput
from app.services.revenue_service import RevenueForecastService
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/predict/revenue", tags=["revenue"])

@router.post("", response_model=RevenueForecastOutput)
async def forecast_revenue(input_data: RevenueForecastInput) -> RevenueForecastOutput:
    """
    Forecast future revenue based on SaaS metrics
    
    Takes:
    - Current MRR
    - Growth rate
    - Churn rate
    - Expansion rate
    - Forecast period
    
    Returns:
    - Projected MRR/ARR
    - Month-by-month breakdown
    - Confidence level
    - Key business metrics
    """
    try:
        logger.info(f"Forecasting revenue with current MRR: ${input_data.current_mrr}")
        
        result = RevenueForecastService.forecast(input_data)
        
        logger.info(f"Forecast complete. Projected ARR: ${result.arr_projected}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error forecasting revenue: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Forecast failed: {str(e)}"
        )

@router.post("/sensitivity")
async def sensitivity_analysis(input_data: RevenueForecastInput):
    """
    Perform sensitivity analysis on revenue forecast
    Shows impact of changing key variables
    """
    try:
        base_forecast = RevenueForecastService.forecast(input_data)
        
        # Vary growth rate by ±20%
        lower_input = input_data.copy(update={"mrr_growth_rate": input_data.mrr_growth_rate * 0.8})
        higher_input = input_data.copy(update={"mrr_growth_rate": input_data.mrr_growth_rate * 1.2})
        
        lower_forecast = RevenueForecastService.forecast(lower_input)
        higher_forecast = RevenueForecastService.forecast(higher_input)
        
        return {
            "base_case": base_forecast,
            "pessimistic": lower_forecast,
            "optimistic": higher_forecast,
            "range": {
                "min_arr": lower_forecast.arr_projected,
                "max_arr": higher_forecast.arr_projected,
                "variance": higher_forecast.arr_projected - lower_forecast.arr_projected
            }
        }
    except Exception as e:
        logger.error(f"Error in sensitivity analysis: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
```

---

## 🚀 STEP 7: Main FastAPI Application

### **7.1 Create app/main.py**
```python
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

from app.config import settings
from app.routes import health, churn, revenue
from app.models.loader import model_loader

# Configure logging
logging.basicConfig(level=settings.log_level)
logger = logging.getLogger(__name__)

# Lifespan context manager
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("🚀 STRAT_IQ API Starting...")
    logger.info(f"Models path: {settings.churn_model_path}")
    try:
        # Models are loaded on first import
        logger.info("✅ Models loaded successfully")
    except Exception as e:
        logger.error(f"❌ Failed to load models: {e}")
        raise
    
    yield
    
    # Shutdown
    logger.info("🛑 STRAT_IQ API Shutting down...")

# Create FastAPI app
app = FastAPI(
    title=settings.api_title,
    version=settings.api_version,
    description="AI-powered decision intelligence platform for SaaS revenue & churn prediction",
    lifespan=lifespan
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(health.router)
app.include_router(churn.router)
app.include_router(revenue.router)

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Welcome to STRAT_IQ Intelligence Layer",
        "version": settings.api_version,
        "endpoints": {
            "health": "/health",
            "churn": "/predict/churn",
            "revenue": "/predict/revenue",
            "docs": "/docs"
        }
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug
    )
```

---

## ▶️ STEP 8: Running the Application

### **8.1 Create run_api.sh**
```bash
#!/bin/bash

# Activate virtual environment
source venv/bin/activate

# Create .env from .env.example if not exists
if [ ! -f .env ]; then
    cp .env.example .env
fi

# Start FastAPI server
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### **8.2 Run the API**
```bash
# Make script executable
chmod +x run_api.sh

# Run
./run_api.sh

# Or directly
python -m uvicorn app.main:app --reload --port 8000

# Visit:
# http://localhost:8000/docs (Interactive API docs)
# http://localhost:8000/health (Health check)
```

---

## 📡 STEP 9: Testing Endpoints

### **9.1 Test Churn Prediction**
```bash
curl -X POST "http://localhost:8000/predict/churn" \
  -H "Content-Type: application/json" \
  -d '{
    "engagement_score": 0.65,
    "nps_score": 7,
    "product_adoption_rate": 0.75,
    "payment_failures": 2,
    "support_tickets_last_30d": 3,
    "customer_age_months": 18,
    "cac_payback_months": 8,
    "active_users_ratio": 0.6,
    "contract_length_months": 12,
    "churn_risk_flag": 0
  }'
```

### **9.2 Test Revenue Forecast**
```bash
curl -X POST "http://localhost:8000/predict/revenue" \
  -H "Content-Type: application/json" \
  -d '{
    "current_mrr": 50000,
    "mrr_growth_rate": 8,
    "churn_rate": 4.5,
    "expansion_rate": 3,
    "forecast_months": 6,
    "previous_revenues": [42000, 45000, 48000, 49000, 49500]
  }'
```

### **9.3 Interactive API Testing**
```
Open browser: http://localhost:8000/docs
- See all endpoints
- Try requests interactively
- View request/response schemas
```

---

## 🔒 STEP 10: Error Handling & Validation

The Pydantic schemas automatically validate:
```
✅ Data types
✅ Field ranges (min/max)
✅ Required fields
✅ Field descriptions

Returns helpful error messages:
❌ "Field validation failed for 'engagement_score': 
   ensure this value is less than or equal to 1"
```

---

## 🚢 DEPLOYMENT READY

Your API is ready for:
```
✅ Local development (localhost:8000)
✅ Docker containerization
✅ Cloud deployment (Railway, Heroku, AWS Lambda)
✅ Production use (with gunicorn/uvicorn)
```

---

## 📊 NEXT STEPS (Frontend Integration)

After API is running:

1. **Note API endpoints:**
   - `http://localhost:8000/predict/churn`
   - `http://localhost:8000/predict/revenue`

2. **In your Next.js frontend, create hooks:**
   ```typescript
   // hooks/useChurnPrediction.ts
   export function useChurnPrediction() {
     return useMutation({
       mutationFn: async (data) =>
         fetch('http://localhost:8000/predict/churn', {
           method: 'POST',
           body: JSON.stringify(data)
         }).then(r => r.json())
     })
   }
   ```

3. **Connect form inputs to API calls**

4. **Display results beautifully**

---

**YOU'RE READY TO BUILD! 🚀**

Start with Step 1, follow sequentially, and you'll have a production-ready API in 2-3 hours!
